#!/bin/bash

base_dir=$(dirname $0)

pushd $base_dir

./setup_venv.sh

popd      