class Action:
    def call(self, *args, **kwargs):
        pass